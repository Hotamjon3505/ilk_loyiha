

a =[1,2 ,4,5,]
b = [5, 6, 2, 7, 8]
s = 0
for i in a:
    s += i
print(f"a ning yig'ndisi  = {s}")
s = 0
for i in b:
    s += i
print(f"b ning yig'n disi  = {s}")